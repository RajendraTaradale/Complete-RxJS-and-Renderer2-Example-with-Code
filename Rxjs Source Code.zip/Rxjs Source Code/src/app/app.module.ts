import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { CounterService } from './counter.service';
import { HttpClientModule } from '@angular/common/http';
import { CP7Directive } from './CP7Directive';
import { CP8Directive } from './CP8Directive';
import { CP9Directive } from './CP9Directive';
import { ListenDemoComponent } from './Listen-Demo.Component';
import { DebouneDemoComponent } from './deboune-demo/deboune-demo.component';
import { ReactiveFormsModule } from '@angular/forms';
import { LoadingDirectiveDirective } from './loading-directive.directive';
import { LoadingComponentComponent } from './loading-component/loading-component.component';
import { LoaderDirective } from './loader.dir';
import { TestingLoaderComponent } from './testing-loader/testing-loader.component';
import { RxjsDemoComponent } from './rxjs-demo/rxjs-demo.component';

@NgModule({
  declarations: [
    AppComponent, CP7Directive, CP8Directive, CP9Directive,
    ListenDemoComponent, DebouneDemoComponent, LoadingDirectiveDirective, LoadingComponentComponent, LoaderDirective, TestingLoaderComponent, RxjsDemoComponent
  ],
  imports: [
    BrowserModule, HttpClientModule, ReactiveFormsModule
  ],
  providers: [CounterService],
  bootstrap: [AppComponent],
  entryComponents : [LoadingComponentComponent]
})
export class AppModule { }
