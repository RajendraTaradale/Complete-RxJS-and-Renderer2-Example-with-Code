import { Component, OnInit, OnChanges, SimpleChanges } from '@angular/core';
import { CounterService } from '../counter.service';
import { LoaderSyncService } from '../loader-sync.service';

@Component({
  selector: 'app-testing-loader',
  templateUrl: './testing-loader.component.html',
  styleUrls: ['./testing-loader.component.css'],
  providers: [LoaderSyncService]
})
export class TestingLoaderComponent implements OnInit {

  tempData: any;
  countNumber: number = 1;
  isLoader: boolean;
  constructor(private ser: LoaderSyncService, private serData: CounterService) {
    this.isLoader = false;
   }

  ngOnInit() {
    this.isLoader = this.ser.GetFlage();
  }


  submitDiv3() {
    this.ser.SetFlage(true);
    this.isLoader = true;
    this.countNumber++;
    this.tempData = 'Loading..';
    debugger;
    setTimeout(() => {
       this.serData.get9post(this.countNumber).subscribe(s => {
         this.tempData = s;
         this.isLoader = false;
         this.ser.SetFlage(false);
        });
    }, 2000);
  }


}
