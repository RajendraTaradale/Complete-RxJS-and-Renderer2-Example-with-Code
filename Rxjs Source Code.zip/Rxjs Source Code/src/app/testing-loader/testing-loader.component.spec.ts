import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TestingLoaderComponent } from './testing-loader.component';

describe('TestingLoaderComponent', () => {
  let component: TestingLoaderComponent;
  let fixture: ComponentFixture<TestingLoaderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TestingLoaderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestingLoaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
