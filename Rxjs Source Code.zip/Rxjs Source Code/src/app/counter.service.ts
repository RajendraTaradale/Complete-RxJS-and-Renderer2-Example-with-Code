  import { Injectable } from '@angular/core';
  import { HttpClient } from '@angular/common/http';
  import { Observable, of } from 'rxjs';
  import { share, map , mergeMap  } from 'rxjs/operators';
  import { modelclass } from './modelclass';


  @Injectable({
    providedIn: 'root'
  })
  export class CounterService {
    mergeMapdata: any;
    contract: any;
  data: any;
  postdata: any;
  two : any;
    constructor(private http: HttpClient) {  }

    getLastCounter(id): Observable<any> {
          // tslint:disable-next-line:no-trailing-whitespace
      return this.http.get('https://jsonplaceholder.typicode.com/posts/' + id);
    }

    getPost5Data(): Observable<any> {
      return this.postdata;
    }


    get8post(id): Observable<any> {
            // tslint:disable-next-line:no-trailing-whitespace
        return this.http.get('https://jsonplaceholder.typicode.com/posts/' + id);
      }

      get9post(id): Observable<any> {
        // tslint:disable-next-line:no-trailing-whitespace
       return this.http.get('https://jsonplaceholder.typicode.com/posts/' + id);
     }

  CalloneAfter(id: number): any {
    this.test();
      this.mergeMapdata = this.http.get('https://jsonplaceholder.typicode.com/posts/' + id).pipe(
        mergeMap((data5: modelclass) => this.http.get('https://jsonplaceholder.typicode.com/posts/' + data5.userId))
      );
      this.mergeMapdata.subscribe((x: any) => console.log(x));
    }

    test() {
       const one = this.http.get('https://jsonplaceholder.typicode.com/posts/' + 5);

      this.two = one.pipe(mergeMap(abc => of(abc = this.http.get('https://jsonplaceholder.typicode.com/posts/' + 6))));
     console.log('5+6 value');
     this.two.subscribe((x: any) => console.log(x));
    }
  }
