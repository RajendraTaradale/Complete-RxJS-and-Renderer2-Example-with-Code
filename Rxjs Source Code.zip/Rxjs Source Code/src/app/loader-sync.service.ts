import { Injectable } from '@angular/core';

@Injectable()
export class LoaderSyncService {

  callerData: any[];
 Isloader: boolean;

 constructor() {
   this.Isloader = false;
 }

  AddCaller(caller) {
    this.callerData.push(caller);
  }

  GetCaller() {
    return this.callerData;
  }

  GetFlage() {
    return this.Isloader;
  }

  SetFlage(val: boolean) {
    this.Isloader = val;
  }

}
