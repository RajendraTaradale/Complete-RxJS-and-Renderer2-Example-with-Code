// import {Component} from '@angular/core';
// import {FormControl} from '@angular/forms';
// import {Observable} from 'rxjs';
// import 'rxjs/add/operator/debounceTime';
// import 'rxjs/add/operator/throttleTime';
// import 'rxjs/add/observable/fromEvent';
// import { Subscription } from 'rxjs';
// import { debounceTime } from 'rxjs/operators';

// @Component({
//   // tslint:disable-next-line:component-selector
//   selector: 'db-app',
//   template: `<input type=text [value]="firstName" [formControl]="firstNameControl">
//     <br>{{firstName}}
//     <footer>Angular version: {{angularVersion}}</footer>`
// })
// export class DbComponent {
//   angularVersion   = '2.0.0-rc.5';
//   firstName        = 'Name';
//   firstNameControl = new FormControl();
//   formCtrlSub: Subscription;
//   resizeSub:   Subscription;
//   constructor() { console.clear();  }
//   // tslint:disable-next-line:use-life-cycle-interface
//   ngOnInit() {
//     // debounce keystroke events
//     this.firstNameControl.valueChanges.pipe(debounceTime(500)).subscribe(newValue => this.firstName = newValue);
//     // this.formCtrlSub = this.firstNameControl.valueChanges.pipe(
//     // debounceTime(1000).subscribe(newValue => this.firstName = newValue));

//     // throttle resize events
//     // this.resizeSub = Observable.fromEvent(window, 'resize')
//     //   .throttleTime(200)
//     //   .subscribe(e => {
//     //     console.log('resize event', e);
//     //     this.firstName += '*';
//     //   });
//   }

//   // tslint:disable-next-line:use-life-cycle-interface
//   ngOnDestroy() {
//     // this.formCtrlSub.unsubscribe();
//     this.resizeSub.unsubscribe();
//   }
// }
