import { Directive, ComponentRef, ComponentFactory, Input, ViewContainerRef, TemplateRef, ComponentFactoryResolver } from '@angular/core';
import { LoadingComponentComponent } from './loading-component/loading-component.component';

@Directive({
  selector: '[appLoadingDirective]'
})
export class LoadingDirectiveDirective {

  loadingFactory: ComponentFactory<LoadingComponentComponent>;
  loadingComponent: ComponentRef<LoadingComponentComponent>;

  constructor(private templateRef: TemplateRef<any>,
    private vcRef: ViewContainerRef,
    private componentFactoryResolver: ComponentFactoryResolver) {
    // Create resolver for loading component
    this.loadingFactory = this.componentFactoryResolver.resolveComponentFactory(LoadingComponentComponent);
  }

  @Input()
  set apploading(loading: boolean) {
   this.vcRef.clear();

    if (loading) {
      debugger;
      // create and embed an instance of the loading component
      this.loadingComponent = this.vcRef.createComponent(this.loadingFactory);
    } else {
      // embed the contents of the host template
      this.vcRef.createEmbeddedView(this.templateRef);
    }
  }

 

}
