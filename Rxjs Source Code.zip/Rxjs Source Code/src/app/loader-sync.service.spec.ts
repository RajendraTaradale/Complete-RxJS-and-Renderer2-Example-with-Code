import { TestBed, inject } from '@angular/core/testing';

import { LoaderSyncService } from './loader-sync.service';

describe('LoaderSyncService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [LoaderSyncService]
    });
  });

  it('should be created', inject([LoaderSyncService], (service: LoaderSyncService) => {
    expect(service).toBeTruthy();
  }));
});
