import {Component, OnInit} from '@angular/core';
import {FormControl} from '@angular/forms';
import { Observable, Subscription } from 'rxjs';
import { debounceTime, throttleTime } from 'rxjs/operators';
import { CounterService } from '../counter.service';

@Component({
  selector: 'app-deboune-demo',
  templateUrl: './deboune-demo.component.html',
  styleUrls: ['./deboune-demo.component.css']
})
export class DebouneDemoComponent implements OnInit {

  firstName = 'Rajendra';
  lastName = '';
  firstNameControl = new FormControl();
  lastNameControl = new FormControl();
  formCtrlSub: Subscription;
  resizeSub:   Subscription;
 data: any;

  constructor(private ser: CounterService) { console.clear();  }
  Get5Data() {
    this.data = this.ser.postdata;
  }
  ngOnInit() {
     // debounce keystroke events
     this.firstNameControl.valueChanges.pipe(debounceTime(1000)).subscribe(newValue => this.firstName = newValue);
     // throttle resize events
          this.lastNameControl.valueChanges.pipe(throttleTime(2000)).subscribe(e => {
          this.lastName = e;
       this.lastName += '*'; });
     }

  // tslint:disable-next-line:use-life-cycle-interface
  ngOnDestroy() {
    this.formCtrlSub.unsubscribe();
    this.resizeSub.unsubscribe();
  }

}
