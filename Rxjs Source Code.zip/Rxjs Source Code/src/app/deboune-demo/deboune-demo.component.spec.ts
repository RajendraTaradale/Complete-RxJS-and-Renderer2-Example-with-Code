import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DebouneDemoComponent } from './deboune-demo.component';

describe('DebouneDemoComponent', () => {
  let component: DebouneDemoComponent;
  let fixture: ComponentFixture<DebouneDemoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DebouneDemoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DebouneDemoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
