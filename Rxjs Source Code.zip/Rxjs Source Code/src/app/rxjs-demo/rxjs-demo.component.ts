import { Component, OnInit, Renderer2, ViewChild, AfterViewInit  } from '@angular/core';
import { Observable } from 'rxjs';
import { ElementRef } from '@angular/core';
import { Subject, BehaviorSubject, ReplaySubject, AsyncSubject } from 'rxjs';

@Component({
  selector: 'app-rxjs-demo',
  templateUrl: './rxjs-demo.component.html',
  styleUrls: ['./rxjs-demo.component.css']
})
export class RxjsDemoComponent implements OnInit, AfterViewInit  {
   // https://medium.com/front-end-hacking/creating-an-observable-with-angular-part-ii-the-4-different-types-3d8fd2835850
  data: any;
  constructor(private el: ElementRef, private renderer: Renderer2) { }

  @ViewChild('myId') myId: ElementRef;

  ngOnInit() {
    this.data = Observable.create((observer: any) => {
    observer.next('Hey Guys RXJS');
  });
  }

ngAfterViewInit() {
    this.data = Observable.create((observer: any) => {
      observer.next('Hey Guys RXJS');
      observer.next('Hey Guys RXJS 2');
      observer.complete();
      observer.next('Hey Guys RXJS Last');
    });
    this.data.subscribe((d: any) => this.AddItem(d, this.myId.nativeElement));
    console.log(this.myId.nativeElement);


 // *********************************Subject************************
      let subject = new Subject();
      subject.subscribe(
        dt => this.AddItem(dt, this.myId.nativeElement),
        err => this.AddItem(err, this.myId.nativeElement),
        () => this.AddItem('Observation 1 Complete', this.myId.nativeElement)
      );
     subject.next('subject 1 : Data for Obs 1');
     subject.next('subject 1 : Data for Obs 2');

      // *********************************Behaviou Subject************************

      let Bsubject = new BehaviorSubject('First');
      Bsubject.subscribe(
        dt => this.AddItem('Behaviour Subject 1 : ' + dt, this.myId.nativeElement),
        err => this.AddItem(err, this.myId.nativeElement),
        () => this.AddItem('Observation 1 Complete', this.myId.nativeElement)
      );
      Bsubject.next('Data for Obs 1');
      Bsubject.next('Data for Obs 1');
      Bsubject.next('Behaviour Subject 2 is about to subscribe');

      let Obs2 = Bsubject.subscribe(
        data => this.AddItem('Behaviour Subject 2 : ' + data, this.myId.nativeElement)
      );

      Bsubject.next('Data for Obs 2');

      Obs2.unsubscribe();

      Bsubject.next('Last Data for Obs');

       // *********************************Reply Subject************************

       let Rsubject = new ReplaySubject(2);
       Rsubject.subscribe(
         dt => this.AddItem('ReplaySubject Subject 1 : ' + dt, this.myId.nativeElement),
         err => this.AddItem(err, this.myId.nativeElement),
         () => this.AddItem('Observation 1 Complete', this.myId.nativeElement)
       );
       Rsubject.next('Data for Obs 1');
       Rsubject.next('Data for Obs 1');
       Rsubject.next('Behaviour Subject 2 is about to subscribe');

      let Obs3 = Rsubject.subscribe(
        data => this.AddItem('ReplaySubject Subject 2 : ' + data, this.myId.nativeElement)
      );
      Rsubject.next('Data for Obs 2');
      Obs3.unsubscribe();
      Rsubject.next('Last Data for Obs');

       // *********************************Async Subject************************
       let AS = new AsyncSubject<number>();

       AS.subscribe(
                (dts: number) => this.AddItem('Asyncsubject 1 : ' + dts, this.myId.nativeElement),
        );

       AS.next(1);
       AS.next(2);
       AS.next(3);
       AS.next(4);
       AS.complete();
      }

  AddItem(val: any, par: any) {
  const lispan: Element = this.renderer.createElement('li');
  const litextspan: Element = this.renderer.createText(val);
  this.renderer.appendChild(lispan, litextspan);
  this.renderer.appendChild(par, lispan);
  }
}
