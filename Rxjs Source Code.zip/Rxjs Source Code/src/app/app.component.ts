import { Component, ElementRef, Renderer2, HostListener, ViewChild } from '@angular/core';
import { CounterService } from './counter.service';
import { Subscription, Observable } from 'rxjs';
import {share } from 'rxjs/operators';
import {forkJoin} from 'rxjs';
import { LoaderSyncService } from './loader-sync.service';
// import { forkJoin } from 'rxjs/observable';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers: [LoaderSyncService]
})
export class AppComponent {
  tempDatatwo: {};
  isLoadertwo: boolean=false;
   countNumber = 0;
   req: any = null; // Isubsctipon
   rawData: any;
   shareData: any;
   dt8: any;
   dt9: any;
   joinData: any;
   settrue: boolean;
   tempData: any;
   isLoader: boolean;

   @ViewChild('abcd') private abcd: ElementRef;
   constructor(private ser: CounterService, private elRef: ElementRef, private renderer: Renderer2, private loader: LoaderSyncService) {
        console.log(ser.getPost5Data());
        this.settrue = true;
    }
  showList() {
      this.countNumber++;
     if (this.req != null && !this.req.closed) {
          this.req.unsubscribe();
      }
      this.req = this.ser.getLastCounter(this.countNumber).subscribe(
              res => {
                this.rawData = res;
        });
      }
   stopCall() {
      this.req.unsubscribe();
    }

    onclick() {
      const li = this.renderer.createElement('li');
      const text = this.renderer.createText('Click here to add li');
      this.renderer.appendChild(li, text);
      this.renderer.appendChild(this.abcd.nativeElement, li);
    }

    Get5Data() {
      this.shareData = this.ser.getPost5Data();
    }

    GetforkMergeData() {
      this.dt8 = this.ser.get8post(8);
      this.dt9 = this.ser.get8post(9);
      forkJoin(this.dt8, this.dt9).subscribe((res: any[]) => console.log(res));
     // console.log(this.joinData);

    }

    calloneAfterOther() {
      this.ser.CalloneAfter(9);
    }

    submitDiv1() {
      this.isLoader = true;
      this.countNumber++;
      this.tempData = 'Loading..';
      setTimeout(() => {
         this.ser.get9post(this.countNumber).subscribe(s => {
           this.tempData = s;
           this.isLoader = false;
          });
      }, 2000);
    }

    submitDiv2() {
      this.isLoadertwo = true;
      this.countNumber++;
      this.tempDatatwo = 'Loading..';
      setTimeout(() => {
         this.ser.get9post(this.countNumber).subscribe(s => {
          this.tempDatatwo = s;
           this.isLoadertwo = false;
          });
      }, 2000);
    }

}
