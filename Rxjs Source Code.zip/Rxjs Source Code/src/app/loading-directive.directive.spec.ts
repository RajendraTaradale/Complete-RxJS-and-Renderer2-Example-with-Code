import { LoadingDirectiveDirective } from './loading-directive.directive';

describe('LoadingDirectiveDirective', () => {
  it('should create an instance', () => {
    const directive = new LoadingDirectiveDirective();
    expect(directive).toBeTruthy();
  });
});
